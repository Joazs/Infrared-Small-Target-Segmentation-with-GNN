import torch.nn as nn
import numpy as np
import  torch

def SoftIoULoss( pred, target):
        # Old One
        pred = torch.sigmoid(pred)#这里进行Sigmoid
        smooth = 1

        # print("pred.shape: ", pred.shape)
        # print("target.shape: ", target.shape)

        intersection = pred * target
        loss = (intersection.sum() + smooth) / (pred.sum() + target.sum() -intersection.sum() + smooth)

        # loss = (intersection.sum(axis=(1, 2, 3)) + smooth) / \
        #        (pred.sum(axis=(1, 2, 3)) + target.sum(axis=(1, 2, 3))
        #         - intersection.sum(axis=(1, 2, 3)) + smooth)

        loss = 1 - loss.mean()
        # loss = (1 - loss).mean()

        return loss

def BCELoss(pred, target, alpha=1, beta=100):
	pred = torch.sigmoid(pred)###这里Sigmoid
	bce = nn.BCELoss(reduction='mean')
	good = bce(pred, target)
	loss = alpha * torch.log(1. + beta*good)
	return loss

def Focal_Loss(pred, target, alpha=0.5, gamma=2, reduction='mean'):
	pt = torch.sigmoid(pred)#[B,1,H,W],sigmoid
	
	loss = - alpha * (1 - pt) ** gamma * target * torch.log(pt) - (1 - alpha) * pt ** gamma * (1 - target) * torch.log(1 - pt)#[B,1,H,W]
	if reduction == 'mean':
		loss = torch.mean(loss)
	elif reduction == 'sum':
		loss = torch.sum(loss)
	return loss#一个数

class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


