from tqdm             import tqdm
import torch.optim    as optim
from torch.optim      import lr_scheduler
from torchvision      import transforms
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torch
import torch.nn as nn

from utils.utils import *
from utils.metrics import *
from utils.loss import *
from utils.load_param_data import  load_dataset, load_param

from nets.module import Net

input_shape = [512, 512]
Batch_size = 4
max_lr = 0.003
Epochs = 500

cynb = -10000

class Trainer(object):
	def __init__(self):
		self.save_dir = 'saved_model/'
		
		dataset_dir = 'sirst427'
		train_img_ids, val_img_ids, test_txt = load_dataset(dataset_dir, 'idx_427')
		input_transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([.485, .456, .406], [.229, .224, .225])])
		trainset        = TrainSetLoader(dataset_dir,img_id=train_img_ids,base_size=input_shape[0],crop_size=input_shape[1],transform=input_transform,suffix='.png')
		testset        = TestSetLoader(dataset_dir,img_id=val_img_ids,base_size=input_shape[0],crop_size=input_shape[1],transform=input_transform,suffix='.png')
		self.train_data = DataLoader(dataset=trainset, batch_size=Batch_size, shuffle=True, num_workers=0,drop_last=True)
		self.test_data = DataLoader(dataset=testset, batch_size=1, shuffle=False, num_workers=0,drop_last=False)
        
		model = Net(input_shape=input_shape)
		model = model.cuda()
		
		self.model = model
		self.optimizer  = optim.Adagrad(filter(lambda p: p.requires_grad, self.model.parameters()), lr=max_lr)#定义优化器
		
	def training(self, epoch):
		set_optimizer_lr(self.optimizer, epoch, Epochs, max_lr)#设置优化器学习率
		tbar = tqdm(self.train_data)
		self.model.train()
		losses = AverageMeter()
		for i, (data, labels) in enumerate(tbar):
			data = data.cuda()
			labels = labels.cuda()
			
			self.optimizer.zero_grad()
			pred = self.model(data)
			loss = SoftIoULoss(pred, labels)
			save_the_process(loss.item(), None, self.txt_path)###将结果写入.txt
			
			loss.backward()
			self.optimizer.step()
			
			losses.update(loss.item(), pred.size(0))
			
			tbar.set_description('[%d / %d ], lr %.4f, training loss %.4f' % (epoch, Epochs, self.optimizer.state_dict()['param_groups'][0]['lr'], losses.avg))
		self.train_loss = losses.avg
	
	def testing(self, epoch):
		tbar = tqdm(self.test_data)
		self.model.eval()
		iou_metric = SigmoidMetric(thresh=0.)
		nIoU_metric = SamplewiseSigmoidMetric(1, score_thresh=0.5)
		iou_metric.reset()
		nIoU_metric.reset()
		best_iou = 0
		best_nIoU = 0
		total_iou = 0
		total_niou = 0
		global cynb
		
		with torch.no_grad():
			for i, (data, labels) in enumerate(tbar):
				data = data.cuda()
				labels = labels.cuda()
				output = self.model(data)
				
				labels = labels.cpu()
				output = output.cpu()
				
				iou_metric.update(output, labels)
				nIoU_metric.update(output, labels)
				
				_, IoU = iou_metric.get()
				
			if IoU > best_iou:
				best_iou = IoU

			print('IoU:', best_iou)
			if best_iou > cynb:#保存测试结果最好的模型
				cynb = best_iou
				print('save model!')
				torch.save(self.model.state_dict(), 'saved_model/IRGraphSeg_sirst427.pth')#保存模型参数	

if __name__ == '__main__':
	trainer = Trainer()
	for epoch in range(1, Epochs+1):
		trainer.training(epoch)#训练
		trainer.testing(epoch)#测试

	
