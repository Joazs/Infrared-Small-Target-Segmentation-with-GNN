import os
from skimage import io, transform
import torch
import torchvision
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
# import torch.optim as optim
from utils.metrics import *
#from model.metric import *
import numpy as np
from PIL import Image
import glob
import time
import cv2
from tqdm import tqdm
import torch.utils.data as Data

from utils.load_param_data import load_dataset, load_param
from utils.utils import *
from nets.module import Net

input_shape = [512,512]###每张图片的大小

class Trainer(object):
    def __init__(self):

        # Initial
        #self.args  = args
        self.ROC   = ROCMetric(1, 51)#
        self.PD_FA = PD_FA(1, 10, input_shape, distance=3)
        #self.mIoU  = mIoU(1)
        #self.save_prefix = '_'.join([args.model, args.dataset])
        #nb_filter, num_blocks = load_param(args.channel_size, args.backbone)

        # Read image index from TXT
        dataset_dir = 'sirst427'
        train_img_ids, val_img_ids, test_txt=load_dataset(dataset_dir, 'idx_427')

        # Preprocess and load data
        input_transform = transforms.Compose([
                          transforms.ToTensor(),
                          transforms.Normalize([.485, .456, .406], [.229, .224, .225])])
        testset         = TestSetLoader (dataset_dir,img_id=val_img_ids,base_size=input_shape[0], crop_size=input_shape[1], transform=input_transform,suffix='.png')
        self.test_data  = DataLoader(dataset=testset,  batch_size=1, num_workers=0,drop_last=False)

        # Choose and load model (this paper is finished by one GPU)
        model = Net(input_shape=input_shape)
        model           = model.cuda()
        #model.apply(weights_init_xavier)
        #print("Model Initializing")
        self.model      = model

        # Initialize evaluation metrics,好像用不上
        #self.best_recall    = [0,0,0,0,0,0,0,0,0,0,0]#
        #self.best_precision = [0,0,0,0,0,0,0,0,0,0,0]#

        # Load trained model
        checkpoint        = torch.load('saved_model/IRGraphSeg_sirst427.pth')###加载模型参数
        #self.model.load_state_dict(checkpoint['state_dict'])
        self.model.load_state_dict(checkpoint)
        
        print('模型加载成功')
        
        # Test
        self.model.eval()
        tbar = tqdm(self.test_data)
        #losses = AverageMeter()
        
        iou_metric = SigmoidMetric(thresh=0.5)#阈值是0.5,Sigmoid后
        nIoU_metric = SamplewiseSigmoidMetric(1, score_thresh=0.5)#阈值是0.5,Sigmoid后
        iou_metric.reset()
        nIoU_metric.reset()
        best_iou = 0
        best_nIoU = 0
        total_iou = 0
        total_niou = 0
        
        with torch.no_grad():
            num = 0
            for i, ( data, labels) in enumerate(tbar):
                data = data.cuda()
                labels = labels.cuda()

                output = self.model(data)#[1,1,H,W]
                
                labels = labels.cpu()
                output = output.cpu()
                output = torch.sigmoid(output)####在这里做Sigmoid!!!
                
                self.ROC.update(output, labels)
                self.PD_FA.update(output, labels)###Object-Level
                
                iou_metric.update(output, labels)
                nIoU_metric.update(output, labels)
                
                _, IoU = iou_metric.get()
                _, nIoU = nIoU_metric.get()
                ture_positive_rate, false_positive_rate, recall, precision = self.ROC.get()
            FA, PD = self.PD_FA.get(len(val_img_ids))###Object-Level
                
            print('虚警率:', false_positive_rate)
            print('检测率:', ture_positive_rate)
            print('召回率:', recall)
            print('精确率:', precision)
            print('IoU:', IoU, 'nIoU:', nIoU)
            print('#------------------------Object-Level-----------------------#')
            print('PD:', PD)
            print('FA', FA)

def main():
    trainer = Trainer()

if __name__ == "__main__":
    #args = parse_args()
    main()
