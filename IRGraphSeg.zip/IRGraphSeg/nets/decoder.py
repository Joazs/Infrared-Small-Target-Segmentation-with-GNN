import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class MLP(nn.Module):
    def __init__(self, input_dim=2048, embed_dim=768):
        super(MLP, self).__init__()
        #self.proj = nn.Linear(input_dim, embed_dim, bias=True)#
        self.proj = nn.Conv2d(input_dim, embed_dim, 1, 1, bias=True)#

    def forward(self, x):#[B,C1,H,W]
        #x = x.flatten(2).permute(0,2,1)
        x = self.proj(x)
        return x#[B,N,C]

class SegFormerHead(nn.Module):
	def __init__(self, channels=[48,96,240,384], embed_dim=256):
		super(SegFormerHead, self).__init__()
		self.linear_c1 = MLP(channels[0], embed_dim)
		self.linear_c2 = MLP(channels[1], embed_dim)
		self.linear_c3 = MLP(channels[2], embed_dim)
		self.linear_c4 = MLP(channels[3], embed_dim)
		
		self.fuse = nn.Sequential(nn.Conv2d(4*embed_dim, embed_dim, 1, 1),
		                          nn.BatchNorm2d(embed_dim),
		                          nn.GELU()###下面可以再加一个1x1Conv
		                          )
		self.dropout = nn.Dropout2d(0.)
		self.pred = nn.Conv2d(embed_dim, 1, 1, 1, bias=False)#分类用的卷积###原本bias=False
	
	def forward(self, c1, c2, c3, c4):#[B,C1-4,H/pi,W/pi]
		B = c1.shape[0]
		_c1 = self.linear_c1(c1)#.permute(0,2,1).view(B,-1,c1.shape[2],c1.shape[3])#[B,C,H/p,W/p]
		#_c1 = F.interpolate(_c1, size=c1.size()[2:], mode='bilinear', align_corners=False)#本来就这么大了,不用上采样
		
		_c2 = self.linear_c2(c2)#.permute(0,2,1).view(B,-1,c2.shape[2],c2.shape[3])#[B,C,H/2p,W/2p]
		_c2 = F.interpolate(_c2, size=c1.size()[2:], mode='bilinear', align_corners=False)#[B,C,H/p,W/p],up2x
		
		_c3 = self.linear_c3(c3)#.permute(0,2,1).view(B,-1,c3.shape[2],c3.shape[3])#[B,C,H/4p,W/4p]
		_c3 = F.interpolate(_c3, size=c1.size()[2:], mode='bilinear', align_corners=False)#[B,C,H/p,W/p],up4x
		
		_c4 = self.linear_c4(c4)#.permute(0,2,1).view(B,-1,c4.shape[2],c4.shape[3])#[B,C,H/8p,W/8p]
		_c4 = F.interpolate(_c4, size=c1.size()[2:], mode='bilinear', align_corners=False)#[B,C,H/p,W/p],up8x
		
		_c = torch.cat([_c1, _c2, _c3, _c4], dim=1)#[B,4C,H/p,W/p]
		#_c = _c1 + _c2 + _c3 + _c4#[B,C,H/p,W/p]
		_c = self.fuse(_c)#[B,C,H/p,W/p]
		_c = self.dropout(_c)###
		out = self.pred(_c)#[B,1,H/p,W/p]
		return out
		
