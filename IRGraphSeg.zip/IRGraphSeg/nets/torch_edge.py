# 2022.06.17-Changed for building ViG model
#            Huawei Technologies Co., Ltd. <foss@huawei.com>
import math
import torch
from torch import nn
import torch.nn.functional as F
import numpy as np

def pairwise_distance(x):#x[batch_size, num_points, num_dims]
    """
    Compute pairwise distance of a point cloud.
    Args:
        x: tensor (batch_size, num_points, num_dims)
    Returns:
        pairwise distance: (batch_size, num_points, num_points),成对距离
    """
    #torch.mul对两个张量进行对应位置元素乘法
    #torch.sum对张量对应维度进行加法
    with torch.no_grad():
        x_inner = -2*torch.matmul(x, x.transpose(2, 1))#x[batch_size, num_nodes, num_dims]*x[batch_size, num_dims, num_nodes]=[B,num_nodes,num_nodes],矩阵乘法
        x_square = torch.sum(torch.mul(x, x), dim=-1, keepdim=True)#[B, num_nodes, 1]
        y = x_square + x_inner + x_square.transpose(2, 1)#[B,num_blocks,num_blocks]
        return y#返回节点之间的距离[B,num_nodes,num_nodes]


def part_pairwise_distance(x, start_idx=0, end_idx=1):
    """
    Compute pairwise distance of a point cloud.
    Args:
        x: tensor (batch_size, num_points, num_dims)
    Returns:
        pairwise distance: (batch_size, num_points, num_points)
    """
    with torch.no_grad():
        x_part = x[:, start_idx:end_idx]
        x_square_part = torch.sum(torch.mul(x_part, x_part), dim=-1, keepdim=True)
        x_inner = -2*torch.matmul(x_part, x.transpose(2, 1))
        x_square = torch.sum(torch.mul(x, x), dim=-1, keepdim=True)
        return x_square_part + x_inner + x_square.transpose(2, 1)


def xy_pairwise_distance(x, y):#计算点云的成对距离
    """
    Compute pairwise distance of a point cloud.
    Args:
        x: tensor (batch_size, num_points, num_dims)
        y: tensor (batch_size, num_points, num_dims)
    Returns:
        pairwise distance: (batch_size, num_points, num_points)
    """
    with torch.no_grad():
        xy_inner = -2*torch.matmul(x, y.transpose(2, 1))#eg:[4096,256]
        x_square = torch.sum(torch.mul(x, x), dim=-1, keepdim=True)#eg:[B,4096,1]
        y_square = torch.sum(torch.mul(y, y), dim=-1, keepdim=True)#eg:[B,256,1]
        #eg:[B,4096,1]+[B,4096,256]+[B,1,256]=[B,4096,256]
        return x_square + xy_inner + y_square.transpose(2, 1)


def dense_knn_matrix(x, k=16, relative_pos=None):#根据节点特征寻找相似(最近)邻居
    """Get KNN based on the pairwise distance.#基于成对距离获得KNN
    Args:
        x: (batch_size, num_dims, num_points, 1)
        k: int
    Returns:
        nearest neighbors: (batch_size, num_points, k) (batch_size, num_points, k)#返回最近邻居
    """
    with torch.no_grad():
        x = x.transpose(2, 1).squeeze(-1)#交换维度并且除去冗余维度
        batch_size, n_points, n_dims = x.shape
        ### memory efficient implementation ###内存高效实现
        #x[batch_size, num_points, num_dims]
        dist = pairwise_distance(x.detach())#[B, num_nodes, num_nodes],节点距离矩阵
        if relative_pos is not None:#relative_pos[1, num_nodes, num_nodes]
            dist += relative_pos
        _, nn_idx = torch.topk(-dist, k=k) #[b, n, k]返回k个最大元素的下标,取每行的最大值,物理意义代表该节点最近的K个节点下标 [B,256,2*K]->[B,256,3*K]
        #nn_idx[B,num_blocks,K],代表每个图每个节点连接哪K个点
        ######
        center_idx = torch.arange(0, n_points, device=x.device).repeat(batch_size, k, 1).transpose(2, 1)#[B, num_nodes, K]
    return torch.stack((nn_idx, center_idx), dim=0)##

def xy_dense_knn_matrix(x, y, k=16, relative_pos=None):
    """Get KNN based on the pairwise distance.
    Args:
        x: (batch_size, num_dims, num_points, 1)
        k: int
    Returns:
        nearest neighbors: (batch_size, num_points, k) (batch_size, num_points, k)
    """
    with torch.no_grad():
        x = x.transpose(2, 1).squeeze(-1)#[batch_size, num_dims, num_points, 1]->[batch_size, num_nodes, num_dims],eg:[B,4096,48]
        y = y.transpose(2, 1).squeeze(-1)#[batch_size, num_dims, num_points, 1]->[batch_size, num_nodes, num_dims],eg:[B,256,48]
        batch_size, n_points, n_dims = x.shape
        dist = xy_pairwise_distance(x.detach(), y.detach())#[B,4096,256]->[B,1024,256],计算节点之间的距离
        if relative_pos is not None:
            #eg:[B,4096,256]+[1,4096,256]=[B,4096,256]
            dist += relative_pos#节点距离加上相对位置编码
        _, nn_idx = torch.topk(-dist, k=k)#[B,4096,K]->[B,1024,K],取前k个最大值,距离取负物理意义就是取距离最近的节点
        center_idx = torch.arange(0, n_points, device=x.device).repeat(batch_size, k, 1).transpose(2, 1)#中心节点矩阵,每一行K个元素，元素值等于行数-1,eg:[B,4096,K]
    return torch.stack((nn_idx, center_idx), dim=0)#[2, B, num_blocks, K],增加新的维度进行堆叠,表示第几个节点与哪K个节点相连接


class DenseDilated(nn.Module):#
    """
    Find dilated neighbor from neighbor list#从邻居列表中查找扩展的邻居

    edge_index: (2, batch_size, num_points, k)
    """
    def __init__(self, k=9, dilation=1, stochastic=False, epsilon=0.0):
        super(DenseDilated, self).__init__()
        self.dilation = dilation
        self.stochastic = stochastic
        self.epsilon = epsilon
        self.k = k

    def forward(self, edge_index):
        if self.stochastic:
            if torch.rand(1) < self.epsilon and self.training:
                num = self.k * self.dilation
                randnum = torch.randperm(num)[:self.k]
                edge_index = edge_index[:, :, :, randnum]
            else:
                edge_index = edge_index[:, :, :, ::self.dilation]
        else:
            edge_index = edge_index[:, :, :, ::self.dilation]
        return edge_index


class DenseDilatedKnnGraph(nn.Module):#邻接矩阵初始化是根据节点特征之间的K近邻做连接
    """
    Find the neighbors' indices based on dilated knn
    """
    def __init__(self, k=9, dilation=1, stochastic=False, epsilon=0.0):
        super(DenseDilatedKnnGraph, self).__init__()
        self.dilation = dilation
        self.stochastic = stochastic
        self.epsilon = epsilon
        self.k = k
        self._dilated = DenseDilated(k, dilation, stochastic, epsilon)

    def forward(self, x, y=None, relative_pos=None):
        if y is not None:
            #### normalize
            x = F.normalize(x, p=2.0, dim=1)#将某一个维度除以那个维度对应的范数(默认是2范数)
            y = F.normalize(y, p=2.0, dim=1)
            ####
            edge_index = xy_dense_knn_matrix(x, y, self.k * self.dilation, relative_pos)#[2, B, num_blocks, K],初始化邻接矩阵
        else:
            #### normalize
            x = F.normalize(x, p=2.0, dim=1)
            ####
            edge_index = dense_knn_matrix(x, self.k * self.dilation, relative_pos)#
        edge_index = self._dilated(edge_index)#更新邻接矩阵
        return edge_index

