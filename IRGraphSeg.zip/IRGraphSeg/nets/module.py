#CY
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Sequential as Seq
from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from timm.models.helpers import load_pretrained
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from timm.models.registry import register_model
import time
import torchsummary
import torchvision

from resnet18 import ResNet18###
from torch_vertex import Grapher
from torch_nn import act_layer
from decoder import *

class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x):#[B,C,H,W]
        x = self.dwconv(x)
        return x#[B,C,H,W]

class FFN(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act='gelu', drop_path=0.0):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Sequential(
            nn.Conv2d(in_features, hidden_features, 1, stride=1, padding=0),
            nn.BatchNorm2d(hidden_features),
        )
        self.dwconv = DWConv(hidden_features)###DWConv
        self.act = act_layer(act)
        self.fc2 = nn.Sequential(
            nn.Conv2d(hidden_features, out_features, 1, stride=1, padding=0),
            nn.BatchNorm2d(out_features),
        )
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x):#input:[B,in_channels,H,W]
        shortcut = x
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.fc2(x)
        x = self.drop_path(x) + shortcut
        return x

class Stem(nn.Module):
	def __init__(self, out_dim=48, act=None):
		super(Stem, self).__init__()
		self.embed = ResNet18()###
		self.convs = nn.Conv2d(256, out_dim, 1, 1)
		self.norm = nn.BatchNorm2d(out_dim)
	
	def forward(self, x):#[B,3,H,W]
		x = self.embed(x)
		x = self.convs(x)
		x = self.norm(x)
		return x

class Downsample(nn.Module):
    def __init__(self, in_dim=3, out_dim=768):
        super(Downsample, self).__init__()        
        self.conv = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, 3, stride=2, padding=1),
            nn.BatchNorm2d(out_dim),
        )

    def forward(self, x):
        x = self.conv(x)
        return x


class DeepGCN(torch.nn.Module):
    def __init__(self, opt):
        super(DeepGCN, self).__init__()
        k = opt.k
        act = opt.act
        norm = opt.norm
        bias = opt.bias
        epsilon = opt.epsilon
        stochastic = opt.use_stochastic
        conv = opt.conv
        emb_dims = opt.emb_dims
        drop_path = opt.drop_path
        input_shape = opt.input_shape
        self.H, self.W = input_shape[0], input_shape[1]
        patch_length = opt.patch_length
        
        blocks = opt.blocks
        self.n_blocks = sum(blocks)
        channels = opt.channels
        reduce_ratios = [4, 2, 1, 1]#
        dpr = [x.item() for x in torch.linspace(0, drop_path, self.n_blocks)]  # stochastic depth decay rule 
        num_knn = [int(x.item()) for x in torch.linspace(k, k, self.n_blocks)]  # number of knn's k
        max_dilation = (max(self.H, self.W) // patch_length) // max(num_knn)#最多有多少个邻居,防止邻居数超过节点数
        
        self.stem = Stem(out_dim=channels[0], act=act)
        self.pos_embed = nn.Parameter(torch.zeros(1, channels[0], self.H // patch_length, self.W // patch_length))###
        HW = self.H // patch_length * self.W// patch_length#patch的边长为4

        self.backbone = nn.ModuleList([])
        idx = 0
        for i in range(len(blocks)):#主干网络中块的数量,不是分割图片的块,构建主干网络backbone
            if i > 0:#所以只有3个DownSample层
                self.backbone.append(Downsample(channels[i-1], channels[i]))
                HW = HW // 4#节点数量也要随之改变,因为宽高都变成原来的1/2,所以节点变成原来的1/4
            for j in range(blocks[i]):#[2,2,6,2]
                self.backbone += [
                    Seq(
                          Grapher(channels[i], num_knn[idx], min(idx // 4 + 1, max_dilation), conv, act, norm, bias, stochastic, epsilon, reduce_ratios[i], n=HW, drop_path=dpr[idx], relative_pos=True),
                          FFN(channels[i], channels[i] * 4, act=act, drop_path=dpr[idx]),
                          )###
                         ]
                idx += 1
                
        self.backbone = Seq(*self.backbone)

    def forward(self, inputs):#inputs[B,3,256,256]
        Good_Feature = []#创建空列表用于存储有效特征
        good = F.interpolate(self.pos_embed, size=(self.H//4, self.W//4), mode='bilinear', align_corners=True)
        x = self.stem(inputs) + good#x[B,48,64,64]
        B, C, H, W = x.shape
        for i in range(len(self.backbone)):#[B,48,64,64]->[B,384,8,8]
             x = self.backbone[i](x)
             if i==1 or i==4 or i==11 or i==14:
                 Good_Feature.append(x)#将有效特征存储到列表中

        c1, c2, c3, c4 = Good_Feature
        return c1, c2, c3, c4

@register_model
def pvig_ti_gelu(input_shape, pretrained=False, **kwargs):
    class OptInit:
        def __init__(self, num_classes=1000, drop_path_rate=0.1, **kwargs):
            self.k = 12 # neighbor num (default:9)
            self.conv = 'edge' # graph conv layer {edge, mr}
            self.act = 'gelu' # activation layer {relu, prelu, leakyrelu, gelu, hswish}
            self.norm = 'batch' # batch or instance normalization {batch, instance}
            self.bias = True # bias of conv layer True or False
            self.dropout = 0.0 # dropout rate
            self.use_dilation = True # use dilated knn or not
            self.epsilon = 0.2 # stochastic epsilon for gcn
            self.use_stochastic = False # stochastic for gcn, True or False
            self.drop_path = drop_path_rate
            self.blocks = [2,2,6,2] # number of basic blocks in the backbone
            self.channels = [32, 64, 160, 256] # number of channels of deep features
            self.n_classes = num_classes # Dimension of out_channels
            self.emb_dims = 1024 # Dimension of embeddings
            self.input_shape = input_shape #图像大小
            self.patch_length = 4 #切块的边长

    opt = OptInit(**kwargs)
    model = DeepGCN(opt)
    return model


@register_model
def pvig_s_gelu(input_shape, pretrained=False,  **kwargs):
    class OptInit:
        def __init__(self, num_classes=1000, drop_path_rate=0.1, **kwargs):
            self.k = 12 # neighbor num (default:12)
            self.conv = 'edge' # graph conv layer {edge, mr, sage, gin}
            self.act = 'relu' # activation layer {relu, prelu, leakyrelu, gelu, hswish}
            self.norm = 'batch' # batch or instance normalization {batch, instance}
            self.bias = True # bias of conv layer True or False
            self.dropout = 0. # dropout rate
            self.use_dilation = True # use dilated knn or not
            self.epsilon = 0.2 # stochastic epsilon for gcn,膨胀概率
            self.use_stochastic = False # stochastic for gcn, True or False
            self.drop_path = drop_path_rate
            self.blocks = [2,2,6,2] # number of basic blocks in the backbone
            self.channels = [80, 160, 400, 640] # number of channels of deep features
            self.n_classes = num_classes # Dimension of out_channels
            self.emb_dims = 1024 # Dimension of embeddings
            self.input_shape = input_shape #图像大小
            self.patch_length = 4 #切块的边长

    opt = OptInit(**kwargs)
    model = DeepGCN(opt)
    return model

class Net(nn.Module):
	def __init__(self, input_shape=[256,256]):
		super(Net, self).__init__()
		self.H = input_shape[0]
		self.W = input_shape[1]
		#self.backbone = pvig_ti_gelu(input_shape)#
		self.backbone = pvig_s_gelu(input_shape)#
		self.fpn = SegFormerHead(channels=[80,160,400,640])#S
		#self.fpn = SegFormerHead(channels=[32, 64, 160, 256])#Tiny
		
		self.model_init()#模型参数初始化
	
	def model_init(self):
		for m in self.modules():
			if isinstance(m, nn.Conv2d):
				torch.nn.init.kaiming_normal_(m.weight)
				m.weight.requires_grad = True
				if m.bias is not None:
					m.bias.data.zero_()
					m.bias.requires_grad = True
			elif isinstance(m, nn.Linear):
				torch.nn.init.kaiming_normal_(m.weight)
				m.weight.requires_grad = True
				if m.bias is not None:
					m.bias.data.zero_()
					m.bias.requires_grad = True
			elif isinstance(m, nn.BatchNorm2d):
				m.weight.data.fill_(1)
				if m.bias is not None:
					m.bias.data.zero_()
		print('模型初始化成功!')
		print('如果快乐太难,那我祝你平安!')	
	
	def forward(self, x):#输入为三通道图像
		c1, c2, c3, c4 = self.backbone(x)
		pred = self.fpn(c1, c2, c3, c4)#[B,C,H/4,W/4], dna_decoder[B,1,H/4,W/4]
		out = F.interpolate(pred, size=(self.H,self.W), mode='bilinear', align_corners=False)#
		print(out.shape)
		return out


net = Net().cuda()
test = torch.randn(2,3,256,256).cuda()
net(test)

